# -*- coding: utf-8 -*-
"""Staffaggio — verifica dello staffaggio di una passerella portacavi.

Clic sulla passerella  ->  finestra dei cavi  ->  stesso conto dei Passi 1-4
(peso al metro, carico sulla staffa, numero di staffe)  ->  la passerella
diventa VERDE se conforme, ROSSA se no, e una riga di riepilogo con l'id
cliccabile compare nella finestra di output di pyRevit.

Corsie:  [PY] Python puro   [REVIT] Revit API   [ENG] dati e formule   [OUT] console
"""

import os
import math

from pyrevit import revit, script, forms
from pyrevit import DB

from System.Windows.Controls import DockPanel, Dock, TextBlock, TextBox
from System.Windows import Thickness, HorizontalAlignment, VerticalAlignment

from Autodesk.Revit.UI.Selection import ObjectType
from Autodesk.Revit.Exceptions import OperationCanceledException


# ======================================================================
#  print  cap-7-1-cod6a
#  1. CATALOGO E DATI DI PROGETTO ............................... [ENG]
# ======================================================================
PESO_PASSERELLA = 5.00       # kg/m  peso proprio (scheda tecnica del profilo)
INTERASSE       = 1.50       # m     interasse di progetto
CAMPATA_MAX     = 2.00       # m     campata massima della passerella (catalogo)
PORTATA_N       = 1500.0     # N     portata staffa 41/600 (CEI EN 61537)
G               = 9.81       # m/s^2 accelerazione di gravita'

PORTATA_KG = PORTATA_N / G   # ~152.9 kg equivalenti

# Il catalogo non lo chiede all'utente: lo porta con se'. Dieci formazioni
# FG16OR16 con il peso al metro (kg/m, dalle schede tecniche) e una quantita'
# di partenza. Le prime tre riproducono la EC-01 del capitolo (6 / 10 / 24).
CATALOGO = [
    #  nome                peso   quantita' iniziale
    (u"FG16OR16 4G95",     4.10,  6),
    (u"FG16OR16 5G16",     1.35,  10),
    (u"FG16OR16 3G2.5",    0.18,  24),
    (u"FG16OR16 4G70",     3.30,  0),
    (u"FG16OR16 4G50",     2.55,  0),
    (u"FG16OR16 4G25",     1.55,  0),
    (u"FG16OR16 5G10",     0.90,  0),
    (u"FG16OR16 5G6",      0.55,  0),
    (u"FG16OR16 5G2.5",    0.28,  0),
    (u"FG16OR16 3G4",      0.30,  0),
]


# ======================================================================
#  print  cap-7-1-cod6b
#  2. LA FINESTRA DEI CAVI ...................................... [PY]
# ======================================================================
class StaffaggioWindow(forms.WPFWindow):
    """Riempie il guscio XAML: una riga (nome + casella) per ogni cavo."""

    def __init__(self, xaml, catalogo):
        forms.WPFWindow.__init__(self, xaml)
        self.caselle = {}
        self.quantita = None                       # None finche' non si preme Verifica
        for nome, _peso, default in catalogo:
            riga = DockPanel(Margin=Thickness(0, 0, 0, 6))
            casella = TextBox(Width=56, Text=str(default),
                              HorizontalContentAlignment=HorizontalAlignment.Right)
            DockPanel.SetDock(casella, Dock.Right)  # la casella a destra
            etichetta = TextBlock(Text=nome, VerticalAlignment=VerticalAlignment.Center)
            riga.Children.Add(casella)
            riga.Children.Add(etichetta)            # l'etichetta riempie il resto
            self.righe.Children.Add(riga)
            self.caselle[nome] = casella

    def verifica_click(self, sender, args):
        # raccoglie le quantita' digitate e chiude la finestra
        self.quantita = {}
        for nome, casella in self.caselle.items():
            try:
                self.quantita[nome] = int(casella.Text)
            except ValueError:
                self.quantita[nome] = 0
        self.Close()


# ======================================================================
#  3. FUNZIONI DI SUPPORTO REVIT ................................ [REVIT]
# ======================================================================
def in_metri(lung_ft):
    """Converte una lunghezza dai piedi interni ai metri (Legge II)."""
    try:
        return DB.UnitUtils.ConvertFromInternalUnits(lung_ft, DB.UnitTypeId.Meters)
    except Exception:
        return lung_ft * 0.3048


def id_riempimento_pieno(doc):
    """Id del motivo di riempimento 'solido', per tinteggiare la superficie."""
    for fp in DB.FilteredElementCollector(doc).OfClass(DB.FillPatternElement):
        if fp.GetFillPattern().IsSolidFill:
            return fp.Id
    return DB.ElementId.InvalidElementId


def colora(vista, elemento, colore):
    """Dipinge superficie e bordi dell'elemento nella vista attiva (override)."""
    ogs = DB.OverrideGraphicSettings()
    solido = id_riempimento_pieno(vista.Document)
    ogs.SetProjectionLineColor(colore)
    ogs.SetSurfaceForegroundPatternColor(colore)
    ogs.SetCutForegroundPatternColor(colore)
    if solido != DB.ElementId.InvalidElementId:
        ogs.SetSurfaceForegroundPatternVisible(True)
        ogs.SetSurfaceForegroundPatternId(solido)
        ogs.SetCutForegroundPatternVisible(True)
        ogs.SetCutForegroundPatternId(solido)
    vista.SetElementOverrides(elemento.Id, ogs)


# ======================================================================
#  print  cap-7-1-cod6c
#  4. IL FLUSSO: CLIC, CALCOLO, COLORE .......... [REVIT] / [ENG] / [OUT]
# ======================================================================
doc = revit.doc
uidoc = revit.uidoc
out = script.get_output()

VERDE = DB.Color(46, 164, 79)
ROSSO = DB.Color(200, 44, 44)

# 4.1  clic sulla passerella e lettura della lunghezza ......... [REVIT]
try:
    rif = uidoc.Selection.PickObject(ObjectType.Element, "Seleziona la passerella")
except OperationCanceledException:
    script.exit()

tratto = doc.GetElement(rif.ElementId)
curva = getattr(tratto.Location, "Curve", None)
if curva is None:
    forms.alert("L'elemento selezionato non ha una lunghezza (Location.Curve).",
                title="Staffaggio", exitscript=True)
L = in_metri(curva.Length)

# 4.2  la finestra dei cavi .................................... [PY]
XAML = os.path.join(os.path.dirname(__file__), "StaffaggioWindow.xaml")
finestra = StaffaggioWindow(XAML, CATALOGO)
finestra.ShowDialog()
if finestra.quantita is None:
    script.exit()                                   # chiusa senza Verifica

# 4.3  lo stesso conto dei Passi 1-4 .......................... [ENG]
pesi = dict((nome, peso) for nome, peso, _ in CATALOGO)
peso_cavi = sum(pesi[nome] * finestra.quantita.get(nome, 0) for nome in pesi)
w = PESO_PASSERELLA + peso_cavi                     # kg/m
F = w * INTERASSE                                   # kg sulla staffa interna
i_mensola = PORTATA_KG / w                          # m, limite della mensola
i_max = min(i_mensola, CAMPATA_MAX)                 # m, limite di sistema
campate = int(math.ceil(L / INTERASSE))
N = campate + 1                                     # N = ceil(L/i) + 1

conforme = (F <= PORTATA_KG) and (INTERASSE <= i_max)

# 4.4  l'esito VISTO: colora la passerella nel modello ........ [REVIT]
colore = VERDE if conforme else ROSSO
with revit.Transaction("Staffaggio"):
    colora(doc.ActiveView, tratto, colore)

# 4.5  riepilogo con id cliccabile (linkify) .................. [OUT]
esito = "CONFORME" if conforme else "NON CONFORME"
out.print_md("# Staffaggio &mdash; {0}".format(esito))
out.print_md("Passerella: {0}".format(out.linkify(tratto.Id)))
out.print_md("- Lunghezza  L = **{0:.2f} m**".format(L))
out.print_md("- Peso al metro  w = **{0:.2f} kg/m**  (passerella {1:.2f} + cavi {2:.2f})".format(w, PESO_PASSERELLA, peso_cavi))
out.print_md("- Carico staffa  F = w x i = **{0:.1f} kg**   (portata {1:.1f} kg)".format(F, PORTATA_KG))
out.print_md("- Interasse max  i_max = min({0:.2f}; {1:.2f}) = **{2:.2f} m**".format(i_mensola, CAMPATA_MAX, i_max))
out.print_md("- Staffe  N = ceil({0:.2f} / {1:.2f}) + 1 = **{2}**".format(L, INTERASSE, N))
