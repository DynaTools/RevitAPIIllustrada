# -*- coding: utf-8 -*-
# Revit API Illustrata in Python - Paulo Giavoni
# Pulsante pyRevit "Riempimento" (Capitolo 7.2)
# Percorso: RevitApiBook.extension / RevitApiBook.tab /
#           Verifica.panel / Riempimento.pushbutton / script.py
import math

from Autodesk.Revit.DB import (BuiltInParameter, Color,
                               FilteredElementCollector, FillPatternElement,
                               OverrideGraphicSettings, Transaction)
from Autodesk.Revit.UI.Selection import ObjectType
from pyrevit import revit, script

FT_MM = 304.8                      # 1 piede = 304.8 mm
LIMITE_PRASSI = 0.40               # buona prassi: 40 % di riempimento

# catalogo: sezione -> diametro esterno massimo (mm),
# tabella CEI-UNEL 35318, cavi FG16R16 0,6/1 kV unipolari
CATALOGO = [("FG16R16 16", 11.4), ("FG16R16 25", 13.2),
            ("FG16R16 35", 14.6), ("FG16R16 50", 16.4),
            ("FG16R16 70", 17.3), ("FG16R16 95", 20.4),
            ("FG16R16 120", 22.4), ("FG16R16 150", 24.8),
            ("FG16R16 185", 27.2), ("FG16R16 240", 30.4),
            ("FG16R16 300", 33.0)]

COLORI = {"CONFORME":     (Color(0, 150, 60),  "verde"),
          "AL LIMITE":    (Color(235, 160, 0), "giallo"),
          "NON CONFORME": (Color(200, 30, 30), "rosso")}

uidoc = revit.uidoc
doc = revit.doc
out = script.get_output()

# 1) il clic sul cavidotto
try:
    ref = uidoc.Selection.PickObject(ObjectType.Element,
                                     "Seleziona il cavidotto")
except Exception:
    script.exit()                  # l'utente ha premuto ESC

conduit = doc.GetElement(ref.ElementId)

p_int = conduit.get_Parameter(BuiltInParameter.RBS_CONDUIT_INNER_DIAM_PARAM)
if p_int is None:
    out.print_md("# Riempimento del cavidotto")
    out.print_md("L'elemento scelto **non e' un cavidotto**: "
                 "non ha un diametro interno.")
    script.exit()

De = p_int.AsDouble() * FT_MM
A_tubo = math.pi / 4.0 * De ** 2

# 2) la distinta dei cavi, letta dai parametri di progetto
righe = []
A_cavi = 0.0
somma_d2 = 0.0
n_cavi = 0
for nome, d in CATALOGO:
    par = conduit.LookupParameter(nome)
    q = par.AsInteger() if par is not None else 0
    if q == 0:
        continue                   # assente, o dichiarato ma non passa
    A_cavi += math.pi / 4.0 * d ** 2 * q
    somma_d2 += d ** 2 * q
    n_cavi += q
    righe.append("| {} | {:.1f} | {} |".format(nome, d, q))

if n_cavi == 0:
    out.print_md("# Riempimento del cavidotto")
    out.print_md("Questo tratto **non dichiara nessun cavo**. "
                 "Compila le quantita' nella tavolozza delle proprieta', "
                 "poi premi di nuovo il pulsante.")
    script.exit()

# 3) il calcolo e le due soglie
#    K = Dt^2 / De^2, quindi De >= 1,3 Dt equivale a K <= 59,2 %:
#    da sola la norma e' piu' permissiva della buona prassi
K = A_cavi / A_tubo
Dt = math.sqrt(somma_d2)
De_min = 1.3 * Dt
norma = De >= De_min
prassi = K <= LIMITE_PRASSI

if not norma:
    esito = "NON CONFORME"
elif not prassi:
    esito = "AL LIMITE"
else:
    esito = "CONFORME"

colore, nome_colore = COLORI[esito]

# 4) l'esito sul modello (Legge I: in Transaction)
pieno = None
for fp in FilteredElementCollector(doc).OfClass(FillPatternElement):
    if fp.GetFillPattern().IsSolidFill:
        pieno = fp
        break

ogs = OverrideGraphicSettings()
ogs.SetProjectionLineColor(colore)
if pieno is not None:
    ogs.SetSurfaceForegroundPatternId(pieno.Id)
    ogs.SetSurfaceForegroundPatternColor(colore)
    ogs.SetSurfaceForegroundPatternVisible(True)

t = Transaction(doc, "Riempimento del cavidotto")
t.Start()
doc.ActiveView.SetElementOverrides(conduit.Id, ogs)
t.Commit()

# 5) il rapporto nella finestra di output
out.print_md("# Riempimento del cavidotto")
out.print_md("\n".join(["| cavo | d (mm) | q |", "|---|---:|---:|"] + righe))
out.print_md("Diametro interno **De = {:.1f} mm**, "
             "area del tubo **{:.0f} mm2**".format(De, A_tubo))
out.print_md("Area occupata **{:.0f} mm2** da **{}** cavi".format(
    A_cavi, n_cavi))
out.print_md("Riempimento **{:.1f} %** (buona prassi: max {:.0f} %)".format(
    K * 100, LIMITE_PRASSI * 100))
out.print_md("Fascio **Dt = {:.1f} mm**, minimo CEI 64-8 "
             "**1,3 x Dt = {:.1f} mm**".format(Dt, De_min))
out.print_md("## {}".format(esito))
if not norma:
    out.print_md("Il tubo e' troppo stretto: mancano "
                 "**{:.1f} mm** di diametro.".format(De_min - De))
elif not prassi:
    out.print_md("La norma passa con **{:.1f} mm** di margine, ma il "
                 "riempimento supera il {:.0f} % di buona prassi.".format(
                     De - De_min, LIMITE_PRASSI * 100))
else:
    out.print_md("Margine sul minimo di norma: **{:.1f} mm**.".format(
        De - De_min))
out.print_md("Il cavidotto e' stato colorato in **{}** "
             "nella vista attiva.".format(nome_colore))
